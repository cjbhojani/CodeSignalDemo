//
//  ViewController.swift
//  MRGroupTechDemo
//
//  Created by Rajnikant Bhojani on 31/05/22.
//

import UIKit
import SDWebImage

class ProductData: UITableViewCell {
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var imgProduct: UIImageView!
}

class ViewController: BaseVC {
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var txtSearch: UITextField!
    
    var viewModel = ViewModel()
    var arrProductData = NSArray()
    var arrFilterData = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewModel.apiAddNewPost(dicParam: [:]) { isSucess, receivedData in
            if isSucess ?? false {
                self.arrProductData = receivedData ?? []
                self.tblView.reloadData()
            }
        }
    }
    
    @IBAction func searchValue(_ sender: UITextField) {
        arrFilterData = arrProductData.filter { (($0 as! NSDictionary).value(forKey: "name") as?  String)!.contains(sender.text ?? "") } as NSArray
        
        self.tblView.reloadData()
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.arrFilterData.count == 0 {
            return self.arrProductData.count
        } else {
            return self.arrFilterData.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let productCell = tableView.dequeueReusableCell(withIdentifier: Identifier.ProductData.rawValue, for: indexPath) as! ProductData
        
        let singleProductData: NSDictionary?
        if self.arrFilterData.count == 0 {
            singleProductData = self.arrProductData[indexPath.row] as? NSDictionary
        } else {
            singleProductData = self.arrFilterData[indexPath.row] as? NSDictionary
        }
        
        productCell.lblProductName.text = singleProductData?.value(forKey: "name") as? String
        productCell.lblDescription.text = singleProductData?.value(forKey: "description") as? String
        
        let price = (singleProductData?.value(forKey: "currency") as? String ?? "") + (String(singleProductData?.value(forKey: "price") as? Int ?? 0))
        productCell.lblPrice.text = price
        productCell.imgProduct.sd_setImage(with: URL(string: singleProductData?.value(forKey: "imgUrl") as? String ?? ""), placeholderImage: nil)
        return productCell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let singleProductData = self.arrProductData[indexPath.row] as? NSDictionary
        let productDetailsVC = Storyboard.main.storyboard().instantiateViewController(withIdentifier: Identifier.ProductDetail.rawValue) as! ProductDetailVC
        productDetailsVC.productID = singleProductData?.value(forKey: "id") as? String ?? ""
        self.navigationController?.pushViewController(productDetailsVC, animated: true)
    }
}
