//
//  ProductDetailVC.swift
//  MRGroupTechDemo
//
//  Created by Rajnikant Bhojani on 02/07/22.
//

import UIKit

class ReviewCell: UITableViewCell {
    @IBOutlet weak var lblReview: UILabel!
}

class ProductDetailVC: BaseVC {
    
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var tblReview: UITableView!
    
    var viewModel = ViewModel()
    var productID = String()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewModel.apiProductDetails(dicParam: [:], id: productID) { isSucess, receivedData in
            if isSucess ?? false {
                self.imgView.sd_setImage(with: URL(string: receivedData?.value(forKey: "imgUrl") as? String ?? ""), placeholderImage: nil)
                self.lblName.text = receivedData?.value(forKey: "name") as? String
                self.lblDescription.text = receivedData?.value(forKey: "description") as? String
                let price = (receivedData?.value(forKey: "currency") as? String ?? "") + (String(receivedData?.value(forKey: "price") as? Int ?? 0))
                self.lblPrice.text = price
            }
        }
    }
    
    @IBAction func btnAddReviewClick(_ sender: UIButton) {
        let reviewVC = Storyboard.main.storyboard().instantiateViewController(withIdentifier: Identifier.Review.rawValue) as! ReviewVC
        reviewVC.modalPresentationStyle = .overFullScreen
        self.present(reviewVC, animated: true, completion: nil)
    }
}


extension ProductDetailVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Identifier.ReviewCell.rawValue, for: indexPath) as! ReviewCell
        
        cell.lblReview.text = "Review \(indexPath.row)"
        
        return cell
    }
}
