//
//  ViewModel.swift
//  MRGroupTechDemo
//
//  Created by Rajnikant Bhojani on 31/05/22.
//

import UIKit
import RxSwift
import Alamofire



struct ViewModel {
    
    func apiAddNewPost(dicParam: [String: Any], completion :@escaping (_ isSucess : Bool?,_ receivedData: NSArray?) -> Void) {
        ServiceManager.sharedInstance.getRequest(parameterDict: dicParam, URL: API.product.URL) { dicResponse, error in
            do {
                if dicResponse != nil {
                    completion(true, dicResponse)
                } else {
                    completion(false, nil)
                }
            }
        }
    }
    
    func apiProductDetails(dicParam: [String: Any], id: String, completion :@escaping (_ isSucess : Bool?,_ receivedData: NSDictionary?) -> Void) {
        ServiceManager.sharedInstance.getRequestWothDictionary(parameterDict: dicParam, URL: API.productDetail.URL + id) { dicResponse, error in
            do {
                if dicResponse != nil {
                    completion(true, dicResponse)
                } else {
                    completion(false, nil)
                }
            }
        }
    }
}

