
//  Created by Darshan Gajera on 03/26/20.
//  Copyright © 2020 Calendar. All rights reserved.
//

import UIKit
import RxAlamofire
import Alamofire
import RxSwift
import RxCocoa
import Reachability

struct ImageData {
    var name: String?
    var img: UIImage?
}

enum API : String {
    static let BaseURL = "http://localhost:3001/"
    case product = "product"
    case productDetail = "product/"
    var URL : String {
        get{
            return API.BaseURL + self.rawValue
        }
    }
}


class ServiceManager: NSObject {
    let disposeBag = DisposeBag()
    static let sharedInstance : ServiceManager = {
        let instance = ServiceManager()
        return instance
    }()
    
    func postRequest(parameterDict: [String: Any], URL aUrl: String, isLoader: Bool = true, isSuccessAlert: Bool = false, isFailureAlert: Bool = true, block: @escaping (NSDictionary?, NSError?) -> Void) {
            print("URL: \(aUrl)")
            print("Param: \(parameterDict)")

            if Reachability.Connection.self != .none {
                if isLoader {
                    LoadingView.startLoading()
                }
                RxAlamofire.requestJSON(.post,aUrl, parameters: parameterDict)
                    .debug()
                    .subscribe(onNext: { (r, json) in
                        do {
                            if isLoader {
                                LoadingView.stopLoading()
                            }
                            if r.statusCode == 200 {
                                print("response:\(json)")
                                let dicData = json as! NSDictionary
                                print("response:\(dicData)")
                                if let error = dicData.value(forKey: "errors") as? NSArray {
                                    if error.count > 0 {
                                        let msg = (error.firstObject as! NSDictionary).value(forKey: "message") as! String
                                        SnackBar.show(strMessage: msg, type: .negative)
                                    }
                                } else {
                                    let status: Int = dicData.value(forKey: "status") as! Int
                                    if status == 200 {
                                        if isSuccessAlert {
                                            if dicData.value(forKey: "msg") != nil {
                                                SnackBar.show(strMessage: dicData.value(forKey: "message") as! String, type: .positive)
                                            }
                                        }
                                        block(dicData, nil)
                                    } else {
                                        if isFailureAlert {
                                            SnackBar.show(strMessage: dicData.value(forKey: "message") as! String, type: .negative)
                                            block(nil, nil)
                                        } else {
                                            block(nil, nil)
                                        }
                                    }
                                }
                            } else if r.statusCode == 404 {
                                if isFailureAlert {
                                    let dicData = json as! NSDictionary
                                    SnackBar.show(strMessage: dicData.value(forKey: "message") as! String, type: .negative)
                                }

                                
                            } else if r.statusCode == 403 || r.statusCode == 401 {



                            } else if r.statusCode == 500 {
                                
                            }
                        }
                    }, onError: {(error) in
                        LoadingView.stopLoading()
                       SnackBar.show(strMessage: error.localizedDescription, type: .negative)
                    })
                    .disposed(by: disposeBag)
            }
        }
    
    
    func getRequest(parameterDict:[String : Any], URL aUrl: String, isLoader: Bool = true, isSuccessAlert: Bool = true , isFailureAlert: Bool = true, block: @escaping (NSArray?, NSError?) -> Void) {
        if Reachability.Connection.self != .none {
            
             print("URL: \(aUrl)")
             print("Param: \(parameterDict)")
            
        
            let header: [String: String] = ["accept": "application/json"]
            if Reachability.Connection.self != .none {
                if isLoader {
                    LoadingView.startLoading()
                }
                
                RxAlamofire.requestJSON(.get,aUrl, headers:header)
                    .debug()
                    .subscribe(onNext: { (r, json) in
                        do {
                            LoadingView.stopLoading()
                            if r.statusCode == 200 {
                                let dicData = json as! NSArray
                                print("Response = ", json)
                                block(dicData, nil)
                            } else {
                                block(nil, nil)
                            }
                        }
                    }, onError: {(error) in
                        LoadingView.stopLoading()
                    })
                    .disposed(by: disposeBag)
            }
        }
    }
    
    func getRequestWothDictionary(parameterDict:[String : Any], URL aUrl: String, isLoader: Bool = true, isSuccessAlert: Bool = true , isFailureAlert: Bool = true, block: @escaping (NSDictionary?, NSError?) -> Void) {
        if Reachability.Connection.self != .none {
            
             print("URL: \(aUrl)")
             print("Param: \(parameterDict)")
            
        
            let header: [String: String] = ["accept": "application/json"]
            if Reachability.Connection.self != .none {
                if isLoader {
                    LoadingView.startLoading()
                }
                
                RxAlamofire.requestJSON(.get,aUrl, headers:header)
                    .debug()
                    .subscribe(onNext: { (r, json) in
                        do {
                            LoadingView.stopLoading()
                            if r.statusCode == 200 {
                                let dicData = json as! NSDictionary
                                print("Response = ", json)
                                block(dicData, nil)
                            } else {
                                block(nil, nil)
                            }
                        }
                    }, onError: {(error) in
                        LoadingView.stopLoading()
                    })
                    .disposed(by: disposeBag)
            }
        }
    }
    
    
    
    
    func postWithMultipart(parameterDict: [String: Any], arrImage: [UIImage], URL aUrl: String, isLoader: Bool = true, isSuccessAlert: Bool = false, isFailureAlert: Bool = true, block: @escaping (NSDictionary?, NSError?) -> Void) {
        if Reachability.Connection.self != .none {
            if isLoader {
                LoadingView.startLoading()
            }
            var header: [String: String]?
            header = ["Authorization":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2NTA2OTE3MDQsImV4cCI6MTY4MjIyNzcwNH0.VJlEAot_mp73G8mFyzZ5QzBMcNJaZKccSVGysuo85gY"]
            Alamofire.upload(multipartFormData: { multipartFormData in
                for i in 0 ..< arrImage.count {
                    let imgData = arrImage[i].jpegData(compressionQuality: 0.5)
                    multipartFormData.append(imgData!, withName: "picture_link_\(i + 1)",fileName: "picture_link_\(i + 1)", mimeType: "image/jpg")
                }
                
                for (key, value) in parameterDict {
                    multipartFormData.append(String("\(value)").data(using: String.Encoding.utf8)!, withName: key )
                }
                print("URL: ",aUrl)
                print("Parameter: ",parameterDict)
                
            } ,to:aUrl, headers: header)
            {(result) in
                switch result {
                case .success(let upload, _, _):
                    upload.uploadProgress(closure: {(progress) in
                        print("Upload Progress: \(progress.fractionCompleted)")
                    })
                    upload.responseJSON { response in
                        switch response.result {
                        case .success:
                            do {
                                LoadingView.stopLoading()
                                if let result = response.result.value {
                                    let dicData = result as! NSDictionary
                                    print("response:\(dicData)")
                                    if let error = dicData.value(forKey: "errors") as? NSArray {
                                        if error.count > 0 {
                                            let msg = (error.firstObject as! NSDictionary).value(forKey: "msg") as! String
                                            SnackBar.show(strMessage: msg, type: .negative)
                                        }
                                    } else {
                                        let status: Bool = dicData.value(forKey: "success") as! Bool
                                        if status {
                                            block(dicData, nil)
                                        } else {
                                            block(nil, nil)
                                        }
                                    }
                                }
                            }
                        case .failure(let responseError):
                            LoadingView.stopLoading()
                            print("responseError: \(responseError)")
                        }
                    }
                case .failure(let encodingError):
                    LoadingView.stopLoading()
                    print(encodingError)
                }
            }
        }
    }
}

extension URL {
    /// Creates an NSURL with url-encoded parameters.
    init?(string : String, parameters : [String : String]) {
        guard var components = URLComponents(string: string) else { return nil }
        components.queryItems = parameters.map { return URLQueryItem(name: $0, value: $1) }
        guard let url = components.url else { return nil }
        // Kinda redundant, but we need to call init.
        self.init(string: url.absoluteString)
    }
}
