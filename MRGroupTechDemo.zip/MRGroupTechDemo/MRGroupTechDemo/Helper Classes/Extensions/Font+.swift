//
//  Font+.swift
//  FullKit
//
//  Created by Darshan Gajera on 21/06/18.
//  Copyright © 2018 Darshan Gajera. All rights reserved.
//

import Foundation
import UIKit

struct AppFont {
    let standard = "Didot"
    let halvetica = "Halvetica"
    let arial = "Arial"
}
