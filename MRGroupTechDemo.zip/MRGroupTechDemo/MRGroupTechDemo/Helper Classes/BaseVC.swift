//
//  NBSBaseViewController.swift
//  DemoBank
//
//  Created by Vikram on 11/26/16.
//  Copyright © 2016 SDL. All rights reserved.
//

import Foundation
import UIKit
import CoreData
import SDWebImage
import Reachability
import UserNotifications
import UserNotificationsUI
import MessageUI
import QuartzCore
import CoreLocation
import EventKit
import RxCocoa
import RxSwift
import MBProgressHUD


import StoreKit
import Alamofire

import Photos


//swiftlint:disable all
typealias LeftButton = (_ left: UIButton) -> Void
typealias RightButton = (_ right: UIButton) -> Void

class ClosureSleeve {
    let closure: () -> ()
    
    init(attachTo: AnyObject, closure: @escaping () -> ()) {
        self.closure = closure
        objc_setAssociatedObject(attachTo, "[\(arc4random())]", self, .OBJC_ASSOCIATION_RETAIN)
    }
    
    @objc func invoke() {
        closure()
    }
}

class BaseVC: UIViewController,MFMailComposeViewControllerDelegate {
    let locationManager = CLLocationManager()
    var imgEmptyDataSet = UIImage()
    var titleEmptyDataSet = String()
    var currentLatitude = String()
    var currentLongitude = String()
    let network = NetworkManager.sharedInstance
    let reachability = try! Reachability()
    
//    private var rewardedAd: GADRewardedAd?
    var hideStatusBar: Bool = false {
          didSet {
              setNeedsStatusBarAppearanceUpdate()
          }
      }
    
    override var prefersStatusBarHidden: Bool {
              return hideStatusBar
       }
    
    var hasTopNotch: Bool {
        if #available(iOS 11.0, tvOS 11.0, *) {
            return UIApplication.shared.delegate?.window??.safeAreaInsets.top ?? 0 > 20
        }
        return false
    }
    
    func showAds() -> Bool {
        if AppPrefsManager.sharedInstance.isKeyExistInPreference(key: AppPrefsManager.sharedInstance.ADSDATA) {
            if AppPrefsManager.sharedInstance.getAdsData()?.show_ads ?? false {
                return true
            }
        }
        return false
    }
    
    func setTextfieldBorder(textField: UITextField, isValue: Bool) {
        if isValue {
            textField.layer.borderWidth = 1.0
            textField.layer.borderColor = UIColor.hexStringToUIColor(hex: "F4F9F9").cgColor
        } else {
            textField.layer.borderWidth = 1.0
            textField.layer.borderColor = UIColor.hexStringToUIColor(hex: "D2042D").cgColor
        }
    }
    
    func getStatusBarHeight() -> CGFloat {
       var statusBarHeight: CGFloat = 0
       if #available(iOS 13.0, *) {
           let window = UIApplication.shared.windows.filter {$0.isKeyWindow}.first
           statusBarHeight = window?.windowScene?.statusBarManager?.statusBarFrame.height ?? 0
       } else {
           statusBarHeight = UIApplication.shared.statusBarFrame.height
       }
       return statusBarHeight
   }
    
    func setShadow(view: UIView) {
        DispatchQueue.main.asyncAfter(deadline: .now()+0.1) {
            let shadowPath0 = UIBezierPath(roundedRect: view.bounds, cornerRadius: 6)
            view.layer.masksToBounds = false
            view.layer.bounds = view.bounds
            view.layer.position = view.center
            view.layer.shadowPath = shadowPath0.cgPath
            view.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor
            view.layer.shadowOpacity = 0.3
            view.layer.shadowRadius = 2
            view.layer.shadowOffset = CGSize(width: 0, height: 0)
        }
    }
    
    func rateApp() {
        if #available(iOS 10.3, *) {
            AppPrefsManager.sharedInstance.setIsRated(obj: true)
            SKStoreReviewController.requestReview()
        } else if let url = URL(string: GlobalConstants.AppURL) {
            UIApplication.shared.openURL(url)
        }
    }
    
//    Collectionview 3 image
//    cjbhojani
//    func collectionView(_ collectionView: UICollectionView,
//                        layout collectionViewLayout: UICollectionViewLayout,
//                        sizeForItemAt indexPath: IndexPath) -> CGSize {
//        return CGSize(width: (self.view.frame.size.width / 3) - 1, height: 240)
////        return CGSize(width: (self.view.frame.size.width / 2) - 16, height: 330)
//    }
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
//        return 1
//    }
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
//        return 0.5
//    }
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
//        return UIEdgeInsets(top: 0, left: 0.5, bottom: 0, right: 0.5)
//    }
    
//    func manageRewardedAds() {
//        AppPrefsManager.sharedInstance.setClickCount(obj: AppPrefsManager.sharedInstance.getClickCount()! + 1)
//        if AppPrefsManager.sharedInstance.getClickCount()! % 5 == 0 {
//            GoogleAdsManager.shared.showRewardedVideoAd()
//        }
//    }
    
    func setNavigationBarView(constant: NSLayoutConstraint) {
        if !hasTopNotch {
            constant.constant = 56
        } else {
            constant.constant = 90
        }
    }
    
    
    
    
    func roundCorner(view: UIView, cornerRadius: CGFloat) {
        view.layer.cornerRadius = cornerRadius
        view.layer.masksToBounds = true
        view.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
    }
    
    func bottomCorner(view: UIView, cornerRadius: CGFloat) {
        view.layer.cornerRadius = cornerRadius
        view.layer.masksToBounds = true
        view.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
    }
    
    func share(message: String, link: String) {
        if let link = NSURL(string: link) {
            let objectsToShare = [message,link] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            self.present(activityVC, animated: true, completion: nil)
        }
    }
    
    func addBottomCurve(givenView: UIView, curvedPercent:CGFloat) ->UIBezierPath
    {
        let arrowPath = UIBezierPath()
        arrowPath.move(to: CGPoint(x:0, y:0))
        arrowPath.addLine(to: CGPoint(x:givenView.bounds.size.width, y:0))
        arrowPath.addLine(to: CGPoint(x:givenView.bounds.size.width, y:givenView.bounds.size.height - (givenView.bounds.size.height*curvedPercent)))
        arrowPath.addQuadCurve(to: CGPoint(x:0, y:givenView.bounds.size.height - (givenView.bounds.size.height*curvedPercent)), controlPoint: CGPoint(x:givenView.bounds.size.width/2, y:givenView.bounds.size.height))
        arrowPath.addLine(to: CGPoint(x:0, y:0))
        arrowPath.close()
        return arrowPath
    }
    
    func setImage(img1: UIImageView, img2: UIImageView, img3: UIImageView, btn1: UIButton, btn2: UIButton, btn3: UIButton) {
        img1.image = UIImage(named: "icoRadioSelect")
        img2.image = UIImage(named: "icoRadio")
        img3.image = UIImage(named: "icoRadio")
        btn1.setTitleColor(.black, for: .normal)
        btn2.setTitleColor(.lightGray, for: .normal)
        btn3.setTitleColor(.lightGray, for: .normal)
    }
    
    func setSelectedLookingFor(img1: UIImageView, btn1: UIButton) {
        img1.image = UIImage(named: "icoRadioSelect")
        btn1.setTitleColor(.black, for: .normal)
    }
    
    func setUnselectedLookingFor(img1: UIImageView, btn1: UIButton) {
        img1.image = UIImage(named: "icoRadio")
        btn1.setTitleColor(.lightGray, for: .normal)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        do {
            try reachability.startNotifier()
        } catch {
            print("Unable to start notifier")
        }

        self.navigationController?.navigationItem.backBarButtonItem?.isEnabled = true
        self.navigationController?.interactivePopGestureRecognizer?.delegate = self
    }
    
    func setButtonDesign(btn1: UIButton, btn2: UIButton) {
        btn1.backgroundColor = Color.AppColorCode.color()
        btn1.titleLabel?.textColor = Color.TextColor.color()
        
        btn2.backgroundColor = Color.TextColor.color()
        btn2.titleLabel?.textColor = Color.AppColorCode.color()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

    }
    
    // MARK: Navigation
        func setNavigationBar(title : NSString? ,
                              titleImage : UIImage?,
                              leftImage : UIImage? ,
                              rightImage : UIImage?,
                              leftTitle : String?,
                              rightTitle : String?,
                              isLeft : Bool ,
                              isRight : Bool,
                              isLeftMenu : Bool ,
                              isRightMenu : Bool ,
                              bgColor : UIColor ,
                              textColor : UIColor,
                              isStatusBarSame: Bool,
                              leftClick : @escaping LeftButton ,
                              rightClick : @escaping RightButton)  {
            
//            if isStatusBarSame {
//                if #available(iOS 13.0, *) {
//                    let statusBar =  UIView()
//                    statusBar.frame = UIApplication.shared.statusBarFrame
//                    statusBar.backgroundColor = bgColor
//                    UIApplication.shared.keyWindow?.addSubview(statusBar)
//                } else {
//                    let statusBar1: UIView = UIApplication.shared.value(forKey: "statusBar") as! UIView
//                    statusBar1.backgroundColor = UIColor.white
//                }
//            }
//            
//            self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
//            self.navigationController?.navigationBar.clipsToBounds = true
            
    //        Beizer path for curve navigation controller
//            if #available(iOS 11.0, *) {
//                self.navigationController?.navigationBar.layer.cornerRadius = 20
//                self.navigationController?.navigationBar.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
//            } else {
//                let path = UIBezierPath(roundedRect: (self.navigationController?.navigationBar.bounds)!, byRoundingCorners: [.bottomLeft , .bottomRight], cornerRadii:CGSize(width: 20, height: 20))
//                let maskLayer = CAShapeLayer()
//                maskLayer.frame = (self.navigationController?.navigationBar.bounds)!
//                maskLayer.path = path.cgPath
//                self.navigationController?.navigationBar.layer.mask = maskLayer
//                self.navigationController?.navigationBar.layer.masksToBounds = true
//                // Fallback on earlier versions
//            }
            
            self.navigationItem.hidesBackButton = true
            // Left Item
            let btnLeft : UIButton = UIButton(type: .custom)
            btnLeft.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
            btnLeft.imageView?.contentMode = .scaleAspectFit
            btnLeft.imageEdgeInsets = UIEdgeInsets(top: 3, left: 3, bottom: 3, right: 3)
            let addImg = leftImage
            if leftTitle != nil {
                btnLeft.setTitle(leftTitle, for: .normal)
                self.addConstaintsWithWidth(width: 50, height: 30, btn: btnLeft)
            } else {
                btnLeft.setImage(addImg, for: .normal)
                self.addConstaintsWithWidth(width: 30, height: 30, btn: btnLeft)
            }
            btnLeft.sendActions(for: .touchUpInside)
            let leftBarItem : UIBarButtonItem = UIBarButtonItem(customView: btnLeft)
            if isLeft {
                self.navigationItem.leftBarButtonItem = leftBarItem
            }
            if isLeftMenu {
                btnLeft.addTarget(self, action: #selector(btnLeftMenuOpen(sender:)), for: .touchUpInside)
            } else {
                btnLeft.addAction {
                    leftClick(btnLeft)
                }
            }
            
            // right item
            let btnRight : UIButton = UIButton(type: .custom)
            btnRight.frame = CGRect(x: self.view.frame.size.width, y: 0, width: 25, height: 25)
            btnRight.imageView?.contentMode = .scaleAspectFit
            btnRight.imageEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
            let addImg1 = rightImage
            if rightTitle != nil {
                btnRight.frame = CGRect(x: self.view.frame.size.width, y: 0, width: 50, height: 30)
                btnRight.titleLabel?.font = UIFont.systemFont(ofSize: 18.0)
                btnRight.setTitleColor(UIColor.white, for: .normal)
                btnRight.setTitle(rightTitle, for: .normal)
            } else {
                self.addConstaintsWithWidth(width: 30, height: 30, btn: btnRight)
                btnRight.setImage(addImg1, for: .normal)
            }
            
            btnRight.sendActions(for: .touchUpInside)
            
            let rightBarItem : UIBarButtonItem = UIBarButtonItem(customView: btnRight)
            if isRight {
                self.navigationItem.rightBarButtonItem = rightBarItem
            }
            if isRightMenu {
                btnRight.addTarget(self, action: #selector(btnRightMenuOpen(sender:)), for: .touchUpInside)
            } else {
                btnRight.addAction {
                    rightClick(btnRight)
                }
            }
            
            // title
            if title == nil {
                let imgViewTitle = UIImageView(frame: CGRect(x: self.view.frame.size.width/2-50, y: self.view.frame.size.height/2-40, width:20, height: 40.0)) as UIImageView
                imgViewTitle.backgroundColor = UIColor.clear
                imgViewTitle.contentMode = .scaleAspectFit
                imgViewTitle.image = titleImage
                self.navigationItem.titleView = imgViewTitle
            } else {
                let  lblNavigationTitleLabel = UILabel(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 40.0)) as UILabel
                lblNavigationTitleLabel.text = title! as String
                lblNavigationTitleLabel.font = UIFont.boldSystemFont(ofSize: 18.0)
                lblNavigationTitleLabel.textColor = textColor
                lblNavigationTitleLabel.textAlignment = .center
                lblNavigationTitleLabel.frame = CGRect(x: 100, y: 0, width: 100, height: 100)
                self.navigationItem.titleView = lblNavigationTitleLabel
            }
            
            self.navigationController?.navigationBar.backgroundColor = bgColor
            self.navigationController?.navigationBar.barTintColor = bgColor
            self.navigationController?.navigationBar.isTranslucent = true
        }
    
    @objc func btnLeftMenuOpen(sender: UIButton) {
        
    }

    @objc func btnRightMenuOpen(sender: UIButton) {

    }
    
    func localToUTC(date:String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.calendar = NSCalendar.current
        dateFormatter.timeZone = TimeZone.current

        let dt = dateFormatter.date(from: date)
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"

        return dateFormatter.string(from: dt!)
    }

    func UTCToLocal(date:String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")

        let dt = dateFormatter.date(from: date)
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = "dd MMM, yyyy"

        return dateFormatter.string(from: dt!)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func checkPhotoLibraryPermission() -> Bool {
        let status = PHPhotoLibrary.authorizationStatus()
        if (status == PHAuthorizationStatus.authorized) {
            return true
        }
        
        else if (status == PHAuthorizationStatus.denied) {
            self.showAlert(withTitle: "Oops!!!", withMessage: "You did not give photos permission for save images please go to setting and give permission for save images. \n Thanks :)")
            return false
        }
        
        else if (status == PHAuthorizationStatus.notDetermined) {
            PHPhotoLibrary.requestAuthorization({ (newStatus) in
                if (newStatus == PHAuthorizationStatus.authorized) {}
                else {}
            })
        }
        
        else if (status == PHAuthorizationStatus.restricted) {
            return false
        }
        
        return true
    }
    
    func convertImageToBase64(image: UIImage) -> String {
        let imageData = image.pngData()!
        return imageData.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
    }
    
    func convertBase64ToImage(imageString: String) -> UIImage {
        let imageData = Data(base64Encoded: imageString, options: Data.Base64DecodingOptions.ignoreUnknownCharacters)!
        return UIImage(data: imageData)!
    }
    
    func addConstaintsWithWidth(width: CGFloat ,height: CGFloat, btn: UIButton) {
        NSLayoutConstraint(item: btn, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: width).isActive = true
        NSLayoutConstraint(item: btn, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: height).isActive = true
    }
    
    func delayWithSeconds(_ seconds: Double, completion: @escaping () -> ()) {
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
            completion()
        }
    }
}

extension UIControl {
    func addAction(for controlEvents: UIControl.Event = .primaryActionTriggered, action: @escaping () -> ()) {
        let sleeve = ClosureSleeve(attachTo: self, closure: action)
        addTarget(sleeve, action: #selector(ClosureSleeve.invoke), for: controlEvents)
    }
}

extension Date {
    func localDate() -> Date {
        let nowUTC = Date()
        let timeZoneOffset = Double(TimeZone.current.secondsFromGMT(for: nowUTC))
        guard let localDate = Calendar.current.date(byAdding: .second, value: Int(timeZoneOffset), to: nowUTC) else {return Date()}
        return localDate
    }
}

extension BaseVC : UIGestureRecognizerDelegate {
    
    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        return false
    }
    
    @objc func handlePan(_ gestureRecognizer: UIPanGestureRecognizer) {
        if gestureRecognizer.state == .began || gestureRecognizer.state == .changed {

            let translation = gestureRecognizer.translation(in: self.view)
            // note: 'view' is optional and need to be unwrapped
            gestureRecognizer.view!.center = CGPoint(x: gestureRecognizer.view!.center.x + translation.x, y: gestureRecognizer.view!.center.y + translation.y)
            gestureRecognizer.setTranslation(CGPoint.zero, in: self.view)
        }

    }

    @objc func pinchRecognized(pinch: UIPinchGestureRecognizer) {

        if let view = pinch.view {
            view.transform = view.transform.scaledBy(x: pinch.scale, y: pinch.scale)
            pinch.scale = 1
        }
    }

    @objc func handleRotate(recognizer : UIRotationGestureRecognizer) {
        if let view = recognizer.view {
            view.transform = view.transform.rotated(by: recognizer.rotation)
            recognizer.rotation = 0
        }
    }

    //MARK:- UIGestureRecognizerDelegate Methods
    func gestureRecognizer(_: UIGestureRecognizer,
                           shouldRecognizeSimultaneouslyWith shouldRecognizeSimultaneouslyWithGestureRecognizer:UIGestureRecognizer) -> Bool {
        return true
    }
}

extension BaseVC: CLLocationManagerDelegate {
    // Location
    
    
    func configuredMailComposeViewController(strMail: String) {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        mailComposerVC.setToRecipients([strMail])
        mailComposerVC.setSubject("")
        mailComposerVC.setMessageBody("", isHTML: false)
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposerVC, animated: true, completion: nil)
        }
    }
    
    func removeAllPreference() {
        let domain = Bundle.main.bundleIdentifier!
        UserDefaults.standard.removePersistentDomain(forName: domain)
        UserDefaults.standard.synchronize()
    }
    
    func bottomViewCurve(viewNavigation: UIView) {
        if #available(iOS 11.0, *) {
            viewNavigation.layer.cornerRadius = 20
            viewNavigation.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        } else {
            let path = UIBezierPath(roundedRect: (viewNavigation.bounds), byRoundingCorners: [.bottomLeft , .bottomRight], cornerRadii:CGSize(width: 20, height: 20))
            let maskLayer   = CAShapeLayer()
            maskLayer.frame = (viewNavigation.bounds)
            maskLayer.path  = path.cgPath
            viewNavigation.layer.mask = maskLayer
            viewNavigation.layer.masksToBounds = true
            // Fallback on earlier versions
        }
    }
    
    func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
    
}

extension UIView {
    func addBottomBorderWithColor(color: UIColor, width: CGFloat) {
        let border = CALayer()
        border.backgroundColor = color.cgColor
        border.frame = CGRect(x: 0, y: self.frame.size.height - width,
                              width: self.frame.size.width, height: width)
        self.layer.addSublayer(border)
    }
}



@IBDesignable
public class GradientView: UIView {
    private func createGradient() -> CAGradientLayer {
        let gradient = CAGradientLayer()
        gradient.transform = CATransform3DMakeRotation(.pi / 2, 0, 0, 1)
        gradient.frame = bounds
        layer.insertSublayer(gradient, at: 0)
        return gradient
    }

    private var gradient: CAGradientLayer?

    @IBInspectable
    public var color1: UIColor? {
        didSet {
            updateColors()
        }
    }

    @IBInspectable
    public var color2: UIColor? {
        didSet {
            updateColors()
        }
    }
    
    @IBInspectable
    public var color3: UIColor? {
        didSet {
            updateColors()
        }
    }

    @IBInspectable
    public var color4: UIColor? {
        didSet {
            updateColors()
        }
    }
    
    required public init?(coder: NSCoder) {
        super.init(coder: coder)
        gradient = createGradient()
        updateColors()
    }

    override public init(frame: CGRect) {
        super.init(frame: frame)
        gradient = createGradient()
        updateColors()
    }

    override public func layoutSubviews() {
        super.layoutSubviews()
        gradient?.frame = bounds
    }

    private func updateColors() {
        guard
            let color1 = color1,
            let color2 = color2,
        let color3 = color3,
        let color4 = color4
        else {
            return
        }

        gradient?.colors = [color1.cgColor, color2.cgColor, color3.cgColor, color4.cgColor]
    }
}

extension UIView {
    func insertHorizontalGradient(_ color1: UIColor, _ color2: UIColor, _ color3: UIColor, _ color4: UIColor) -> GradientView {
        let gradientView = GradientView(frame: bounds)
        gradientView.color1 = color1
        gradientView.color2 = color2
        gradientView.color3 = color3
        gradientView.color4 = color4
        gradientView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.insertSubview(gradientView, at: 0)
        return gradientView
    }
}

extension  UIViewController {
    
    func showSaveAlert(withTitle title: String, withMessage message:String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { action in
        })
        alert.addAction(ok)
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true)
        })
    }

    func showAlert(withTitle title: String, withMessage message:String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { action in
        })
        let cancel = UIAlertAction(title: "Cancel", style: .default, handler: { action in
        })
        alert.addAction(ok)
        alert.addAction(cancel)
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true)
        })
    }
}

extension UICollectionView {

    func setEmptyMessage(_ message: String) {
        let messageLabel = UILabel(frame: CGRect(x: 0, y: 0, width: self.bounds.size.width, height: self.bounds.size.height))
        messageLabel.text = message
        messageLabel.textColor = .white
        messageLabel.numberOfLines = 0;
        messageLabel.textAlignment = .center;
        messageLabel.font = UIFont.systemFont(ofSize: 18.0)
        messageLabel.sizeToFit()

        self.backgroundView = messageLabel;
    }

    func restore() {
        self.backgroundView = nil
    }
}

class BorderShimmerView : UIView {
    
    /// allow gradient layer to resize automatically
    override class var layerClass: AnyClass { return CAGradientLayer.self }
    
    /// boilerplate UIView initializers
    init() {
        super.init(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
        commonInit()
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    /// set up everything
    func commonInit() {

        let overlayView = UIView() /// add a view overlaid on the gradient view
        overlayView.backgroundColor = .white
        overlayView.frame = bounds.insetBy(dx: 10, dy: 10) /// appears like a border
        overlayView.autoresizingMask = [.flexibleWidth, .flexibleHeight] /// allow resizing
        self.addSubview(overlayView)
        
        let gradientLayer = self.layer as! CAGradientLayer
        gradientLayer.locations = [0, 0.45, 0.55, 1] /// adjust this to change the colors' spacing
        gradientLayer.colors = [
            UIColor.white.cgColor,
            UIColor.yellow.cgColor, /// yellow + orange for gold effect
            UIColor.orange.cgColor,
            UIColor.white.cgColor
        ]
        
        let framePath = UIBezierPath(roundedRect: bounds, byRoundingCorners: .allCorners, cornerRadii: CGSize(width: 40, height: 40))
        
        let startPointAnimation = CABasicAnimation(keyPath: #keyPath(CAGradientLayer.startPoint))
        startPointAnimation.fromValue = CGPoint(x: 2, y: -1) /// extreme top right
        startPointAnimation.toValue = CGPoint(x: 0, y: 1) /// bottom left
        
        let endPointAnimation = CABasicAnimation(keyPath: #keyPath(CAGradientLayer.endPoint))
        endPointAnimation.fromValue = CGPoint(x: 1, y: 0) /// top right
        endPointAnimation.toValue = CGPoint(x: -1, y: 2) /// extreme bottom left
        
        let animationGroup = CAAnimationGroup() /// group animations together
        animationGroup.animations = [startPointAnimation, endPointAnimation]
        animationGroup.duration = 2
        animationGroup.repeatCount = .infinity /// repeat animation infinitely
        
        gradientLayer.add(animationGroup, forKey: nil)
        
        
    }
}

extension UIDevice {
    var hasNotch: Bool {
        
        // FIXME: Does not work with apps that use SceneDelegate
        // Requires the window var in the AppDelegate
        
        if #available(iOS 11.0, *) {
            return UIApplication.shared.delegate?.window??.safeAreaInsets.bottom ?? 0 > 20
        }
        return false
    }

}

extension UIView {
    enum GlowEffect: Float {
        case small = 0.4, normal = 2, big = 30
    }

    func doGlowAnimation(withColor color: UIColor, withEffect effect: GlowEffect = .normal) {
        layer.masksToBounds = false
        layer.shadowColor = color.cgColor
        layer.shadowRadius = 0
        layer.shadowOpacity = 0.8
        layer.shadowOffset = .zero

        let glowAnimation = CABasicAnimation(keyPath: "shadowRadius")
        glowAnimation.fromValue = 0
        glowAnimation.toValue = effect.rawValue
        glowAnimation.fillMode = .removed
        glowAnimation.repeatCount = .infinity
        glowAnimation.duration = 2
        glowAnimation.autoreverses = true
        layer.add(glowAnimation, forKey: "shadowGlowingAnimation")
    }
}

class SnapGesture: NSObject, UIGestureRecognizerDelegate {

    // MARK: - init and deinit
    convenience init(view: UIView) {
        self.init(transformView: view, gestureView: view)
    }
    init(transformView: UIView, gestureView: UIView) {
        super.init()

        self.addGestures(v: gestureView)
        self.weakTransformView = transformView
    }
    deinit {
        self.cleanGesture()
    }

    // MARK: - private method
    private weak var weakGestureView: UIView?
    private weak var weakTransformView: UIView?

    private var panGesture: UIPanGestureRecognizer?
    private var pinchGesture: UIPinchGestureRecognizer?
    private var rotationGesture: UIRotationGestureRecognizer?

    private func addGestures(v: UIView) {

        panGesture = UIPanGestureRecognizer(target: self, action: #selector(panProcess(_:)))
        v.isUserInteractionEnabled = true
        panGesture?.delegate = self     // for simultaneous recog
        v.addGestureRecognizer(panGesture!)

        pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(pinchProcess(_:)))
        //view.isUserInteractionEnabled = true
        pinchGesture?.delegate = self   // for simultaneous recog
        v.addGestureRecognizer(pinchGesture!)

        rotationGesture = UIRotationGestureRecognizer(target: self, action: #selector(rotationProcess(_:)))
        rotationGesture?.delegate = self
        v.addGestureRecognizer(rotationGesture!)

        self.weakGestureView = v
    }

    private func cleanGesture() {
        if let view = self.weakGestureView {
            //for recognizer in view.gestureRecognizers ?? [] {
            //    view.removeGestureRecognizer(recognizer)
            //}
            if panGesture != nil {
                view.removeGestureRecognizer(panGesture!)
                panGesture = nil
            }
            if pinchGesture != nil {
                view.removeGestureRecognizer(pinchGesture!)
                pinchGesture = nil
            }
            if rotationGesture != nil {
                view.removeGestureRecognizer(rotationGesture!)
                rotationGesture = nil
            }
        }
        self.weakGestureView = nil
        self.weakTransformView = nil
    }




    // MARK: - API

    private func setView(view:UIView?) {
        self.setTransformView(view, gestgureView: view)
    }

    private func setTransformView(_ transformView: UIView?, gestgureView:UIView?) {
        self.cleanGesture()

        if let v = gestgureView  {
            self.addGestures(v: v)
        }
        self.weakTransformView = transformView
    }

    open func resetViewPosition() {
        UIView.animate(withDuration: 0.4) {
            self.weakTransformView?.transform = CGAffineTransform.identity
        }
    }

    open var isGestureEnabled = true

    // MARK: - gesture handle

    // location will jump when finger number change
    private var initPanFingerNumber:Int = 1
    private var isPanFingerNumberChangedInThisSession = false
    private var lastPanPoint:CGPoint = CGPoint(x: 0, y: 0)
    @objc func panProcess(_ recognizer:UIPanGestureRecognizer) {
        if isGestureEnabled {
            //guard let view = recognizer.view else { return }
            guard let view = self.weakTransformView else { return }

            // init
            if recognizer.state == .began {
                lastPanPoint = recognizer.location(in: view)
                initPanFingerNumber = recognizer.numberOfTouches
                isPanFingerNumberChangedInThisSession = false
            }

            // judge valid
            if recognizer.numberOfTouches != initPanFingerNumber {
                isPanFingerNumberChangedInThisSession = true
            }
            if isPanFingerNumberChangedInThisSession {
                return
            }

            // perform change
            let point = recognizer.location(in: view)
            view.transform = view.transform.translatedBy(x: point.x - lastPanPoint.x, y: point.y - lastPanPoint.y)
            lastPanPoint = recognizer.location(in: view)
        }
    }



    private var lastScale:CGFloat = 1.0
    private var lastPinchPoint:CGPoint = CGPoint(x: 0, y: 0)
    @objc func pinchProcess(_ recognizer:UIPinchGestureRecognizer) {
        if isGestureEnabled {
            guard let view = self.weakTransformView else { return }

            // init
            if recognizer.state == .began {
                lastScale = 1.0;
                lastPinchPoint = recognizer.location(in: view)
            }

            // judge valid
            if recognizer.numberOfTouches < 2 {
                lastPinchPoint = recognizer.location(in: view)
                return
            }

            // Scale
            let scale = 1.0 - (lastScale - recognizer.scale);
            view.transform = view.transform.scaledBy(x: scale, y: scale)
            lastScale = recognizer.scale;

            // Translate
            let point = recognizer.location(in: view)
            view.transform = view.transform.translatedBy(x: point.x - lastPinchPoint.x, y: point.y - lastPinchPoint.y)
            lastPinchPoint = recognizer.location(in: view)
        }
    }


    @objc func rotationProcess(_ recognizer: UIRotationGestureRecognizer) {
        if isGestureEnabled {
            guard let view = self.weakTransformView else { return }

            view.transform = view.transform.rotated(by: recognizer.rotation)
            recognizer.rotation = 0
        }
    }


    //MARK:- UIGestureRecognizerDelegate Methods
    func gestureRecognizer(_: UIGestureRecognizer,
                           shouldRecognizeSimultaneouslyWith shouldRecognizeSimultaneouslyWithGestureRecognizer:UIGestureRecognizer) -> Bool {
        return true
    }

}



