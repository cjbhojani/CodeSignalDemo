//
//  AppPrefsManager.swift
//  PastZero
//
//  Created by Sunil Zalavadiya on 7/28/16.
//  Copyright © 2016 Sunil Zalavadiya. All rights reserved.
//

import UIKit
import CoreLocation
// swiftlint:disable all
class AppPrefsManager: NSObject {
    
    static let sharedInstance = AppPrefsManager()
    let USER = "USER"
    let IsIntroFinish = "IsIntroFinish"
    let FavoriteData = "FavoriteData"
    let HOMEDATA = "HOMEDATA"
    let ADSDATA = "ADSDATA"
    let DIAMOND = "DIAMOND"
    let UserType = "UserType"
    let ClickCount = "ClickCount"
    let IsFolderShow = "IsFolderShow"
    let isRated = "isRated"
    func setDataToPreference(data: AnyObject, forKey key: String) {
        do {
            var archivedData = Data()
            if #available(iOS 11.0, *) {
                archivedData = try NSKeyedArchiver.archivedData(withRootObject: data, requiringSecureCoding: true)
            } else {
                archivedData = NSKeyedArchiver.archivedData(withRootObject: data)
            }
            UserDefaults.standard.set(archivedData, forKey: key)
            UserDefaults.standard.synchronize()
        }
        catch {
            print("Unexpected error: \(error).")
        }
    }
    
    func getDataFromPreference(key: String) -> AnyObject? {
        let archivedData = UserDefaults.standard.object(forKey: key)
        if(archivedData != nil) {
            do {
                var unArchivedData: Any?
                if #available(iOS 11.0, *) {
                    unArchivedData =  try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(archivedData as! Data) as AnyObject
                } else {
                    unArchivedData = NSKeyedUnarchiver.unarchiveObject(with: archivedData as! Data) as AnyObject
                }
                return unArchivedData as AnyObject
            } catch {
                print("Unexpected error: \(error).")
            }
        }
        return nil
    }
    
    func removeDataFromPreference(key: String) {
        UserDefaults.standard.removeObject(forKey: key)
        UserDefaults.standard.synchronize()
    }
    
    func isKeyExistInPreference(key: String) -> Bool {
        if(UserDefaults.standard.object(forKey: key) == nil) {
            return false
        }
        return true
    }
    
    func setClickCount(obj: Int) {
        setDataToPreference(data: obj as AnyObject, forKey: ClickCount)
    }
    
    func getClickCount() -> Int? {
        let clickCount = getDataFromPreference(key: ClickCount)
        return clickCount as? Int
    }
    
    func setDiamond(obj: String) {
        setDataToPreference(data: obj as AnyObject, forKey: DIAMOND)
    }
    
    func getDiamond() -> String? {
        let strToken = getDataFromPreference(key: DIAMOND)
        return strToken as? String
    }
    
    func setUserType(obj: String) {
        setDataToPreference(data: obj as AnyObject, forKey: UserType)
    }
    
    func getUserType() -> String? {
        let strToken = getDataFromPreference(key: UserType)
        return strToken as? String
    }
    
    func setIsFolderShow(obj: Bool) {
        setDataToPreference(data: obj as AnyObject, forKey: IsFolderShow)
    }
    
    func setIsFolderShow() -> Bool? {
        let strToken = getDataFromPreference(key: IsFolderShow)
        return strToken as? Bool
    }
    
    func setIsRated(obj: Bool) {
        setDataToPreference(data: obj as AnyObject, forKey: isRated)
    }
    
    func getIsRated() -> Bool? {
        let isRate = getDataFromPreference(key: isRated)
        return isRate as? Bool
    }
    
    func setIntro(obj: Bool) {
        setDataToPreference(data: obj as AnyObject, forKey: IsIntroFinish)
    }
    
    func getIntro() -> Bool? {
        let strToken = getDataFromPreference(key: IsIntroFinish)
        return strToken as? Bool
    }
    
    
    
    func setUserData(obj: Any) {
        setDataToPreference(data: obj as AnyObject, forKey: HOMEDATA)
    }
    
    func getUserData() -> UserData? {
        if self.isKeyExistInPreference(key: HOMEDATA) {
            let user = getDataFromPreference(key: HOMEDATA) as! NSDictionary
            do {
                let objUser = try JSONDecoder().decode(UserData.self, from: (user.dataReturn(isParseDirect: true))!)
                return objUser
            } catch _ {
                
            }
            return nil
        } else {
            return nil
        }
    }
    
    
    func setAdsData(obj: Any) {
        setDataToPreference(data: obj as AnyObject, forKey: ADSDATA)
    }
    
    func getAdsData() -> AdsData? {
        if self.isKeyExistInPreference(key: ADSDATA) {
            let user = getDataFromPreference(key: ADSDATA) as! NSDictionary
            do {
                let objAds = try JSONDecoder().decode(AdsData.self, from: (user.dataReturn(isParseDirect: true))!)
                return objAds
            } catch _ {
                
            }
            return nil
        } else {
            return nil
        }
    }
}

struct AdsData: Codable {
    var app_open_id: String?
    var application_id: String?
    var home_native_index: Int?
    var interstitial_click: Int?
    var interstitial_id: String?
    var native_id: String?
    var rewarded_id: String?
    var save_native_index: Int?
    var show_Native_ads: Bool?
    var show_ads: Bool?
    var show_interstitial: Bool?
    var show_reward: Bool?
}

struct UserData: Codable {
    var Location: String?
    var TherapyServices: String?
    var Speciality: String?
    var GenderIdentity: String?
    var Ethnicity: String?
    var Sexuality: String?
    var PaymentMethod: String?
}

