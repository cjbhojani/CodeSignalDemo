//
//  Constant.swift
//  Whislte
//
//  Created by Darshan Gajera on 5/14/18.
//  Copyright © 2020. All rights reserved.
//
import UIKit
struct GlobalConstants {
    static let APPNAME = "HD Wallpaper"
    static let AppReviewTitle = "If you like our app then please fill free to give a review to us."
    static let ImageBasePath = "https://naazinfotech.com/HDWallpaper/"
    static let LiveWallpaperTitle = "Live Wallpaper"
//    static let ImageBasePath = "https://naazinfotech.com/rajnichanges/"
//    static let ImageBasePath = "https://naazinfotech.com/RajniCompressTry/"
    
    static let AppID = "1608468047"
    static let AppURL = "https://apps.apple.com/in/app/wallpaper-4k-hd-live-3d/id1608468047"
}

struct Review {
    static let Title = "Your opinion matter to us!"
    static let Message = "If you enjoy our app. would you mind rating us on the app store?"
    static let RateNow = "RATE NOW"
    static let NoThanks = "NO, THANKS"
    static let Later = "LATER"
}

struct NotificationName {
    static let HomeDataChange = "HomeDataChange"
    static let CategoryImageChange = "CategoryImageChange"
    static let ImageChange = "ImageChange"
}

struct TrendingCategoryImage {
    static let TrensingImageName: [String] = ["icoAnimal", "icoFlower", "icoLove"]
}

struct GradientColors {
    static let arrColor: [UIColor] = [UIColor.hexStringToUIColor(hex: "000000"), UIColor.hexStringToUIColor(hex: "002946"), UIColor.hexStringToUIColor(hex: "003966"),UIColor.hexStringToUIColor(hex: "00427D")]
}

enum Storyboard: String {
    case main    = "Main"
    case introduction = "Introduction"
    case sideController = "SideController"
    case therapist = "Therapist"
    func storyboard() -> UIStoryboard {
        return UIStoryboard(name: self.rawValue, bundle: Bundle.main)
    }
}

enum Color: String {
    case SliderSelction  = "0080ff"
    case SliderDefault  = "0048b1"
    case SliderTextDefault  = "7887b5"
    case AppColorCode  = "2F435C"
    case BackgroundColor = "191919"
    case TextColor  = "ffffff"
    case DarkAppColorCode  = "01579B"
    case SupporterColorCode  = "e9dae7"
    case errorRed  = "EA2E31"
    case errorGreen  = "5DC15D"
    case TransactionFailed  = "ff4e4e"
    case TransactionSuccess  = "00a71c"
    case TransactionPending  = "ffbf00"
    case WalletFailed  = "ff3b3b"
    case WhiteDarkMode  = "feffff"
    func color() -> UIColor {
        return UIColor.hexStringToUIColor(hex: self.rawValue)
    }
}

struct NotificationType {
    static let tip  = "tip" // Notification Tip
    static let comment  = "comment" // Comment
    static let payPPV  = "payPPV" //Notification ALL
    static let ppvToUser  = "ppvToUser" // PPV history
    static let seenPPV  = "seenPPV" //  Notification ALL
    static let subscribe  = "subscribe" // Other profile
    static let following  = "following" // Other profile
    static let likeComment  = "likeComment" //Comment
    static let likePost  = "likePost" // SinglePost
}

enum Identifier: String {
    // Main Storyboard
    case ProductDetail = "ProductDetailVC"
    case Review = "ReviewVC"
    
    
    // Tableview cell
    case ProductData = "ProductData"
    case ReviewCell = "ReviewCell"
}

struct TabbarIcon {
    static let Home = "icoHome"
    static let HomeSelected = "icoSelectedHome"
    
    static let Search = "icoSearch"
    static let SearchSelected = "icoSelectedSearch"
    
    static let Add = "icoAdd"
    static let AddSelected = "icoAdd"
    
    static let Notification = "icoNotification"
    static let NotificationSelected = "icoSelectedNotification"
    
    static let Profile = "icoTabPlaceholder"
    static let ProfileSelected = "icoTabPlaceholder"
}

struct FirebaseCollection {
    // Main Storyboard
    static let User  = "Users"
    static let Feedback  = "Feedback"
    static let Food  = "Food Vendors"
    static let Floor  = "Floor Plan"
    static let Exhibitor  = "Exhibit Vendors"
    static let Sponsors  = "Sponsors"
    static let Schedule  = "Schedule"
}

struct FirebaseLogEvent {
    static let homePageOpen = "homePageOpen"
    static let homePageClose = "homePageClose"
    static let categoryOpen = "categoryOpen"
    static let categoryClick = "categoryClick"
    static let categoryPageOpen = "categoryPageOpen"
    static let categoryPageClose = "categoryPageClose"
    static let showCategoryImage = "showCategoryImage"
    static let showCategoryImagePreview = "showCategoryImagePreview"
}

struct FirebaseLogParameter {
    static let loginUsername  = "loginUsername"
    static let loginUserFbID  = "loginUserFbID"
    static let acceptUsername  = "acceptUsername"
    static let acceptUserFbID  = "acceptUserFbID"
    static let addOnType  = "addOnType"
}

struct ErrorMesssages {
    static let EmptyTitle = "Please enter title."
    static let EmptyPrice = "Please enter price."
    static let EmptyMobile = "Please select if you want to select mobile or not."
    static let EmptyDescription = "Please enter description."
    static let EmptyLocation = "Please enter location."
    static let EmptyImage = "Please select some images."
    
}

struct SuccessMessages {
    static let DiamondWin = "Congratulations you win diamond"
    static let SaveToFavorite = "Image successfull saved to favorite."
    static let LiveWallpaperDownload = "Live Wallpaper downloaded successfully."
}
