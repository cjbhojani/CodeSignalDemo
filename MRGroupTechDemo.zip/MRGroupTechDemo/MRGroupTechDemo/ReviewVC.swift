//
//  ReviewVC.swift
//  MRGroupTechDemo
//
//  Created by Rajnikant Bhojani on 02/07/22.
//

import UIKit

class ReviewVC: UIViewController {
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var txtView: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        viewBackground.addGestureRecognizer(tap)
    }
    
    @objc func handleTap(_ sender: UITapGestureRecognizer? = nil) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnReviewClick(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
}
